// Nova Asset JS
