<?php

namespace Laravel\Nova\Fields;

interface Downloadable
{
}
