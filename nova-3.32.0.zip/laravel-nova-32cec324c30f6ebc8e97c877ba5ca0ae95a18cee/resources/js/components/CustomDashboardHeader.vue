<template>
  <div />
</template>

<script>
export default {
  props: ['dashboardName'],
}
</script>
