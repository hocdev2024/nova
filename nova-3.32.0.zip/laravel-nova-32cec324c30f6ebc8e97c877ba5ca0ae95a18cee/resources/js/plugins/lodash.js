import lodash from 'lodash'

/**
 * Set Lodash as a global so you don't have to import it
 */
window._ = lodash
